-- Alterando tabela vendas
ALTER TABLE vendas ADD observacoes TEXT DEFAULT NULL NULL;
