-- Alterando tabela vendas
ALTER TABLE vendas ADD observacoes_cliente TEXT DEFAULT NULL NULL;
